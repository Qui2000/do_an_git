<?php

namespace App\Http\Controllers\FrontendApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FootballPitch;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getScheduleOrder($date)
    {
        //Get order theo ngày
    }
}
