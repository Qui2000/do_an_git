<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PitchType extends Model
{
    protected $table = 'loai_san';
}
