<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StatusPutPitch extends Model
{
    protected $table = 'trang_thai_dat_san';
}
