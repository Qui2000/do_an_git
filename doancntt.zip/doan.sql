-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th2 08, 2022 lúc 12:59 PM
-- Phiên bản máy phục vụ: 10.4.22-MariaDB
-- Phiên bản PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_dat_san`
--

CREATE TABLE `chi_tiet_dat_san` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_dat_san` int(11) DEFAULT NULL,
  `ma_san` int(11) UNSIGNED NOT NULL,
  `khung_gio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ma_loai_dv` int(11) NOT NULL,
  `so_luong_dv` int(11) DEFAULT NULL,
  `ngay_gio_huy` date DEFAULT NULL,
  `ngay_su_dung` date DEFAULT NULL,
  `gia_tien` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ma_tk` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `chi_tiet_dat_san`
--

INSERT INTO `chi_tiet_dat_san` (`id`, `ma_dat_san`, `ma_san`, `khung_gio`, `ma_loai_dv`, `so_luong_dv`, `ngay_gio_huy`, `ngay_su_dung`, `gia_tien`, `created_at`, `updated_at`, `ma_tk`) VALUES
(3, 2102011816, 4, '17', 1, 12, '2022-01-06', '2021-12-30', 420000.00, '2021-12-30 06:18:51', '2022-01-06 00:51:28', 1),
(5, 1807000832, 3, '23', 2, 10, NULL, '2021-12-30', 410000.00, '2021-12-30 06:20:34', '2021-12-30 06:20:34', 3),
(6, 1509485703, 1, '16', 1, 12, NULL, '2022-01-01', 400000.00, '2021-12-30 17:37:38', '2021-12-30 17:37:38', 5),
(7, 3869, 3, '6', 2, 12, NULL, '2022-01-04', 280000.00, '2022-01-04 00:42:10', '2022-01-04 00:42:10', 1),
(8, 6587, 1, '5', 2, 12, NULL, '2022-01-04', 280000.00, '2022-01-04 00:42:10', '2022-01-04 00:42:10', 1),
(9, 4603, 1, '5', 1, 12, '2022-01-06', '2022-01-06', 340000.00, '2022-01-05 22:33:24', '2022-01-06 00:30:30', 1),
(10, 2765, 1, '17', 1, 12, NULL, '2022-01-06', 420000.00, '2022-01-06 00:07:47', '2022-01-06 00:07:47', 1),
(11, 2102011816, 4, '17', 1, 12, '2022-01-06', '2021-12-30', 420000.00, '2022-01-06 00:30:19', '2022-01-06 00:55:08', 1),
(13, 3921, 1, '6', 2, 10, NULL, '2022-01-07', 270000.00, '2022-01-06 16:24:13', '2022-01-06 16:54:14', 1),
(14, 2102011816, 4, '17', 1, 12, NULL, '2022-01-07', 420000.00, '2022-01-06 16:24:13', '2022-01-06 16:42:48', 1),
(15, 3921, 1, '17', 1, 8, NULL, '2022-01-07', 380000.00, '2022-01-06 16:24:13', '2022-01-06 16:24:13', 1),
(16, 2608, 1, '16', 1, 12, NULL, '2022-01-08', 400000.00, '2022-01-06 16:55:57', '2022-01-06 16:55:57', 1),
(17, 9295, 1, '17', 2, 5, NULL, '2022-01-09', 325000.00, '2022-01-06 16:55:57', '2022-01-06 19:08:26', 1),
(18, 9295, 1, '18', 1, 8, NULL, '2022-01-09', 400000.00, '2022-01-06 16:55:57', '2022-01-06 16:55:57', 1),
(19, 6610, 1, '5', 1, 12, NULL, '2022-01-01', 340000.00, '2022-01-06 16:58:15', '2022-01-06 16:58:15', 1),
(20, 6610, 1, '6', 2, 10, NULL, '2022-01-01', 270000.00, '2022-01-06 16:58:15', '2022-01-06 16:58:15', 1),
(21, 6610, 1, '7', 2, 8, NULL, '2022-01-01', 260000.00, '2022-01-06 16:58:15', '2022-01-06 16:58:15', 1),
(22, 6610, 1, '8', 2, 12, NULL, '2022-01-01', 280000.00, '2022-01-06 16:58:15', '2022-01-06 16:58:15', 1),
(23, 6610, 1, '9', 2, 7, NULL, '2022-01-01', 255000.00, '2022-01-06 16:58:15', '2022-01-06 16:58:15', 1),
(24, 5789, 1, '5', 1, 12, NULL, '2022-01-07', 340000.00, '2022-01-06 18:46:38', '2022-01-06 18:46:38', 1),
(25, 1906, 1, '7', 2, 12, NULL, '2022-01-07', 280000.00, '2022-01-06 18:51:45', '2022-01-06 18:51:45', 1),
(26, 1906, 1, '8', 1, 12, NULL, '2022-01-07', 340000.00, '2022-01-06 18:51:45', '2022-01-06 18:51:45', 1),
(27, 9984, 1, '5', 1, 12, NULL, '2022-01-10', 340000.00, '2022-01-09 18:11:20', '2022-01-09 18:11:20', 1),
(28, 4970, 1, '6', 1, 12, NULL, '2022-01-10', 340000.00, '2022-01-09 18:11:20', '2022-01-09 18:11:20', 1),
(30, 9803, 1, '6', 2, 10, '2022-01-11', '2022-01-11', 270000.00, '2022-01-10 20:54:27', '2022-01-10 21:56:50', 1),
(31, 9803, 1, '7', 1, 8, NULL, '2022-01-11', 300000.00, '2022-01-10 20:54:27', '2022-01-10 20:54:27', 1),
(32, 3055, 1, '8', 1, 12, NULL, '2022-01-11', 340000.00, '2022-01-10 21:56:34', '2022-01-10 21:56:34', 1),
(34, 7853, 1, '5', 2, 12, NULL, '2022-01-17', 260000.00, '2022-01-17 00:30:04', '2022-01-17 00:30:04', 1),
(35, 4005, 1, '5', 1, 20, NULL, '2022-01-17', 400000.00, '2022-01-17 00:32:35', '2022-01-17 00:32:35', 14),
(36, 4474, 6, '7', 2, 10, NULL, '2022-01-18', 270000.00, '2022-01-17 02:01:36', '2022-01-17 02:01:36', 15),
(37, 3336, 1, '5', 1, 3, NULL, '2022-01-17', 230000.00, '2022-01-17 02:23:39', '2022-01-17 02:23:39', 16),
(38, 5354, 1, '6', 1, 12, NULL, '2022-01-17', 340000.00, '2022-01-17 03:02:11', '2022-01-17 03:02:11', 1),
(39, 4074, 1, '7', 2, 0, NULL, '2022-01-17', 220000.00, '2022-01-17 03:39:41', '2022-01-17 03:39:41', 25),
(40, 2417, 5, '22', 2, 8, NULL, '2022-01-17', 400000.00, '2022-01-17 05:52:14', '2022-01-17 05:52:14', 17),
(41, 5091, 1, '5', 1, 12, NULL, '2022-01-18', 320000.00, '2022-01-18 01:37:54', '2022-01-18 01:37:54', 1),
(42, 5170, 1, '5', 1, 12, NULL, '2022-01-19', 320000.00, '2022-01-19 06:36:47', '2022-01-19 06:36:47', 1),
(43, 9954, 1, '5', 1, 9, NULL, '2022-01-19', 290000.00, '2022-01-19 06:49:09', '2022-01-19 06:49:09', 29),
(44, 9000, 3, '6', 2, 6, NULL, '2022-01-19', 250000.00, '2022-01-19 06:49:09', '2022-01-19 06:49:09', 29),
(45, 2598, 1, '5', 2, 12, NULL, '2022-01-20', 260000.00, '2022-01-19 19:28:49', '2022-01-19 19:28:49', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_tiet_dich_vu`
--

CREATE TABLE `chi_tiet_dich_vu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_dat_san` int(11) NOT NULL,
  `ma_dich_vu` int(11) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dat_san`
--

CREATE TABLE `dat_san` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_tk` int(11) NOT NULL,
  `ngay_dat` date NOT NULL,
  `ten_nguoi_dat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdt_nguoi_dat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ma_trang_thai` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `dat_san`
--

INSERT INTO `dat_san` (`id`, `ma_tk`, `ngay_dat`, `ten_nguoi_dat`, `sdt_nguoi_dat`, `ma_trang_thai`, `created_at`, `updated_at`) VALUES
(3, 1, '2021-12-30', 'Quang Qui', '0877778819', 3, '2021-12-30 06:18:51', '2021-12-30 06:18:51'),
(5, 3, '2021-12-30', 'Quang Huy', '0988899999', 2, '2021-12-30 06:20:34', '2021-12-30 07:28:31'),
(6, 5, '2021-12-31', 'Nguyễn Duy Vinh', '0935456789', 2, '2021-12-30 17:38:23', '2021-12-30 17:38:23'),
(7, 1, '2022-01-04', 'Quang Qui', '0877778819', 2, '2022-01-04 00:42:10', '2022-01-04 00:42:10'),
(8, 1, '2022-01-04', 'Quang Qui', '0877778819', 2, '2022-01-04 00:42:10', '2022-01-04 00:42:10'),
(9, 1, '2022-01-06', 'Quang Qui', '0877778819', 3, '2022-01-05 22:33:24', '2022-01-06 00:30:30'),
(10, 1, '2022-01-06', 'Quang Qui', '0877778819', 2, '2022-01-06 00:07:47', '2022-01-06 00:07:47'),
(11, 1, '2022-01-06', 'Quang Qui', '0877778819', 3, '2022-01-06 00:30:19', '2022-01-06 00:55:08'),
(13, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:24:13', '2022-01-06 16:54:14'),
(14, 1, '2022-01-07', 'Văn Hiếu', '0877778819', 2, '2022-01-06 16:24:13', '2022-01-06 16:38:57'),
(15, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:24:13', '2022-01-06 16:24:13'),
(16, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:55:57', '2022-01-06 16:55:57'),
(17, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:55:57', '2022-01-06 19:07:00'),
(18, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:55:57', '2022-01-06 16:55:57'),
(19, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:58:15', '2022-01-06 16:58:15'),
(20, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:58:15', '2022-01-06 16:58:15'),
(21, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:58:15', '2022-01-06 16:58:15'),
(22, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:58:15', '2022-01-06 16:58:15'),
(23, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 16:58:15', '2022-01-06 16:58:15'),
(24, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 18:46:39', '2022-01-06 18:46:39'),
(25, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 18:51:45', '2022-01-06 18:51:45'),
(26, 1, '2022-01-07', 'Quang Qui', '0877778819', 2, '2022-01-06 18:51:45', '2022-01-06 18:51:45'),
(27, 1, '2022-01-10', 'Quang Qui', '0877778819', 2, '2022-01-09 18:11:20', '2022-01-09 18:11:20'),
(28, 1, '2022-01-10', 'Quang Qui', '0877778819', 2, '2022-01-09 18:11:20', '2022-01-09 18:11:20'),
(30, 1, '2022-01-11', 'Quang Qui', '0877778819', 3, '2022-01-10 20:54:27', '2022-01-10 21:56:50'),
(31, 1, '2022-01-11', 'Quang Qui', '0877778819', 2, '2022-01-10 20:54:27', '2022-01-10 20:54:27'),
(32, 1, '2022-01-11', 'Quang Qui', '0877778819', 2, '2022-01-10 21:56:34', '2022-01-10 21:56:34'),
(34, 1, '2022-01-17', 'Quang Qui', '0877778819', 2, '2022-01-17 00:30:04', '2022-01-17 00:30:04'),
(35, 14, '2022-01-17', 'Anh Khoa', '065072230', 2, '2022-01-17 00:32:35', '2022-01-17 00:32:35'),
(36, 15, '2022-01-17', 'abc', '123', 2, '2022-01-17 02:01:36', '2022-01-17 02:01:36'),
(37, 16, '2022-01-17', 'dcsdc', '0836707111', 2, '2022-01-17 02:23:39', '2022-01-17 02:23:39'),
(38, 1, '2022-01-17', 'Quang Qui', '0877778819', 2, '2022-01-17 03:02:11', '2022-01-17 03:02:11'),
(39, 25, '2022-01-17', 'Trần Quang Phú', '0839641618', 2, '2022-01-17 03:39:41', '2022-01-17 03:39:41'),
(40, 17, '2022-01-17', 'daica', '08897643535', 2, '2022-01-17 05:52:14', '2022-01-17 05:52:14'),
(41, 1, '2022-01-18', 'Quang Qui', '0877778819', 2, '2022-01-18 01:37:54', '2022-01-18 01:37:54'),
(42, 1, '2022-01-19', 'Quang Qui', '0877778819', 2, '2022-01-19 06:36:47', '2022-01-19 06:36:47'),
(43, 29, '2022-01-19', 'văn quý thọ', '0889198108', 2, '2022-01-19 06:49:09', '2022-01-19 06:49:09'),
(44, 29, '2022-01-19', 'văn quý thọ', '0889198108', 2, '2022-01-19 06:49:09', '2022-01-19 06:49:09'),
(45, 1, '2022-01-20', 'Quang Qui', '0877778819', 2, '2022-01-19 19:28:49', '2022-01-19 19:28:49');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dich_vu`
--

CREATE TABLE `dich_vu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_loai_dv` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_tien` double(8,2) NOT NULL,
  `don_vi` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `dich_vu`
--

INSERT INTO `dich_vu` (`id`, `ma_loai_dv`, `ten`, `gia_tien`, `don_vi`, `created_at`, `updated_at`) VALUES
(1, 1, 'Nước khoáng lạc', 10000.00, 100, NULL, NULL),
(2, 2, 'Nước lọc', 5000.00, 100, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `gia_theo_khung_gio`
--

CREATE TABLE `gia_theo_khung_gio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_loai_san` bigint(20) UNSIGNED NOT NULL,
  `khung_gio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gia_tien` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `gia_theo_khung_gio`
--

INSERT INTO `gia_theo_khung_gio` (`id`, `ma_loai_san`, `khung_gio`, `thu`, `gia_tien`, `created_at`, `updated_at`) VALUES
(1, 1, '05:00-06:00', NULL, 200000.00, NULL, '2022-01-16 20:16:26'),
(2, 1, '06:00-07:00', NULL, 220000.00, NULL, NULL),
(3, 1, '07:00-08:00', NULL, 220000.00, NULL, NULL),
(4, 1, '08:00-09:00', NULL, 220000.00, NULL, NULL),
(5, 1, '09:00-10:00', NULL, 220000.00, NULL, NULL),
(6, 1, '14:00-15:00', NULL, 240000.00, NULL, NULL),
(7, 1, '15:00-16:00', NULL, 240000.00, NULL, NULL),
(8, 1, '16:00-17:00', NULL, 280000.00, NULL, NULL),
(9, 1, '17:00-18:00', NULL, 300000.00, NULL, NULL),
(10, 1, '18:00-19:00', NULL, 320000.00, NULL, NULL),
(11, 1, '19:00-20:00', NULL, 320000.00, NULL, NULL),
(12, 1, '20:00-21:00', NULL, 340000.00, NULL, NULL),
(13, 1, '21:00-22:00', NULL, 340000.00, NULL, NULL),
(14, 1, '22:00-23:00', NULL, 360000.00, NULL, NULL),
(15, 1, '23:00-24:00', NULL, 360000.00, NULL, NULL),
(16, 1, '10:00-11:00', NULL, 250000.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_dich_vu`
--

CREATE TABLE `loai_dich_vu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_dv` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `loai_dich_vu`
--

INSERT INTO `loai_dich_vu` (`id`, `ma_dv`, `ten`, `created_at`, `updated_at`) VALUES
(1, 1, 'Nước khoáng', NULL, NULL),
(2, 2, 'Nước lọc', NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_san`
--

CREATE TABLE `loai_san` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `so_luong_nguoi_da` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ma_san` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `loai_san`
--

INSERT INTO `loai_san` (`id`, `ten`, `so_luong_nguoi_da`, `ma_san`, `created_at`, `updated_at`) VALUES
(1, 'Sân 5', '5 người', 1, NULL, NULL),
(2, 'Sân 7', '7 người', 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_11_09_021307_create_quyen_table', 1),
(5, '2021_11_09_021504_create_quidinh_table', 1),
(6, '2021_11_09_021544_create_taikhoan_table', 1),
(7, '2021_11_09_021615_create_loaisan_table', 1),
(8, '2021_11_09_021636_create_san_table', 1),
(9, '2021_11_09_021702_create_dichvu_table', 1),
(10, '2021_11_09_021844_create_loaidichvu_table', 1),
(11, '2021_11_09_022011_create_chitietdatsan_table', 1),
(12, '2021_12_16_030159_create_chitietdichvu_table', 1),
(13, '2021_12_16_030401_create_giatheokhunggio_table', 1),
(14, '2021_12_16_030751_create_trangthaidatsan_table', 1),
(15, '2021_12_16_030936_create_datsan_table', 1),
(16, '2021_12_28_032741_create_payments_table', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `money` double NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vnp_response_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_vnpay` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_bank` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `qui_dinh`
--

CREATE TABLE `qui_dinh` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noi_dung` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `quyen`
--

CREATE TABLE `quyen` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ma_quyen` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `quyen`
--

INSERT INTO `quyen` (`id`, `ten`, `ma_quyen`, `created_at`, `updated_at`) VALUES
(1, 'Quản lý', 0, NULL, NULL),
(2, 'Nhân viên', 1, NULL, NULL),
(3, 'Khách hàng', 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `san`
--

CREATE TABLE `san` (
  `id` int(11) UNSIGNED NOT NULL,
  `ma_loai_san` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mo_ta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `san`
--

INSERT INTO `san` (`id`, `ma_loai_san`, `ten`, `mo_ta`, `created_at`, `updated_at`) VALUES
(1, 1, 'Sân 5A', 'Sân 5A', NULL, NULL),
(3, 1, 'Sân 5B', '5B', NULL, NULL),
(4, 1, 'Sân 5C', '5C', NULL, NULL),
(5, 1, 'Sân 5D', '5D', NULL, NULL),
(6, 1, 'Sân 5E', '5E', NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tai_khoan`
--

CREATE TABLE `tai_khoan` (
  `id` int(11) NOT NULL,
  `ten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `dia_chi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sdt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gioi_tinh` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quoc_tich` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngay_lam_viec` date DEFAULT NULL,
  `ma_quyen` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `tai_khoan`
--

INSERT INTO `tai_khoan` (`id`, `ten`, `email`, `password`, `ngay_sinh`, `dia_chi`, `sdt`, `gioi_tinh`, `quoc_tich`, `ngay_lam_viec`, `ma_quyen`, `created_at`, `updated_at`) VALUES
(1, 'Quang Qui', 'qui@gmail.com', '$2y$10$uvdGmf0Q1PrcVD8om/N7meWFDJsowuO0W5H8wj1GEOrWZFtVNxe7i', '2000-01-02', 'Quang Nam', '0877778819', 'Nam', 'Viet Nam', NULL, 2, '2021-12-22 06:17:13', '2022-01-06 16:44:25'),
(3, 'Quang Huy', 'huy@gmail.com', '$2y$10$CUpzakphQ3NDwlXaXLZYROdGg3u/ZWVnyYONVQV1SjEliyF/Q7lfW', '2021-12-31', 'Quang Nam', '0988899999', 'Nam', 'Viet Nam', NULL, 2, '2021-12-27 23:44:23', '2021-12-30 20:17:58'),
(5, 'Nguyễn Duy Vinh', 'vinh@gmail.com', '$2y$10$9dou.ZBtiS4qdLONdExWvOakvnnHeyLUg0S.V2MWtIKEVXRGimhmm', '2001-01-31', 'Da Nang', '0935456789', 'Nam', 'Viet Nam', NULL, 2, '2021-12-30 17:35:58', '2021-12-30 17:48:07'),
(6, 'Huy Tran', NULL, NULL, '2022-01-01', 'Da Nang', '0877778819', 'Nam', 'Viet Nam', NULL, 2, '2022-01-06 00:47:11', '2022-01-06 00:47:11'),
(10, 'Quản lý', 'admin@gmail.com', '$2y$10$AjXOQE0LgM6Y5iqik2a/9eSozrP7yyaTKiSfa35nNnyfXCR6DfAWi', NULL, 'Da Nang', '0877778888', NULL, 'Viet Nam', NULL, 0, '2022-01-06 18:55:30', '2022-01-06 18:58:02'),
(11, 'Nhân viên', 'personnel@gmail.com', '$2y$10$haFCdxamT1QLopLqpgxPzu7YSWlVuPLDI230nhR/g2x65tDfTKKoG', NULL, NULL, '0707079999', NULL, NULL, NULL, 1, '2022-01-06 19:05:26', '2022-01-06 19:05:26'),
(13, 'Nhân viên', 'nhanvien@gmail.com', '$2y$10$S5tlqaX470cy2wOVwg.8IeFQJpuNtNoA8RRLz2Uv6fW4E475Q98Z.', NULL, NULL, '0877777777', NULL, NULL, NULL, 1, '2022-01-10 20:58:15', '2022-01-10 20:58:15'),
(14, 'Anh Khoa', 'nvanhkhoa148@gmail.com', '$2y$10$CpqK6/RKlJI/dWOPWElUEuYJpreeUiw0YZ3Wo8Io1TJQHGUYZwCEi', NULL, NULL, '065072230', NULL, NULL, NULL, 2, '2022-01-17 00:30:11', '2022-01-17 00:30:11'),
(15, 'abc', 'abc@gmail.com', '$2y$10$M/R.elEZkv8x9GUlSG5rh.8N/GZgTCiCpqA9bltO5RoM4Ni2tKwNO', NULL, NULL, '123', NULL, NULL, NULL, 2, '2022-01-17 01:43:34', '2022-01-17 01:43:34'),
(16, 'dcsdc', 'voanhnguyen1323@gmail.com', '$2y$10$8KJ10Svtsh/NmsBrG6buyOTCWTc2jS12NBVz5DxyWqyfYtW4.AfZa', NULL, NULL, '0836707111', NULL, NULL, NULL, 2, '2022-01-17 02:21:10', '2022-01-17 02:21:10'),
(17, 'daica', 'daica@gmail.com', '$2y$10$bNA1DhBKh1BcbxTVgDEll.crK/Ka4T2JAkUlLgI9Mgeyd.hIN.Jqi', NULL, NULL, '08897643535', NULL, NULL, NULL, 2, '2022-01-17 02:24:22', '2022-01-17 02:24:22'),
(21, 'Minh Tâm', 'tam@gmail.com', '$2y$10$ha3q0DOZ9Vccu5zCBWlvkusvLKe/aUOS4LIl8DXNZt4hhg8l1I.D.', NULL, NULL, '00099999', NULL, NULL, NULL, 2, '2022-01-17 02:28:34', '2022-01-17 02:28:34'),
(22, 'Quang Huy Tran', 'huytran@gmail.com', '$2y$10$cIdAfdCJG.M.3MMwuOYa.eBOlEjXgy0sen5bnfobSqVdAzVGmGdR6', NULL, NULL, '11112345667', NULL, NULL, NULL, 2, '2022-01-17 02:32:49', '2022-01-17 02:32:49'),
(23, 'Tung', 'tung@gmail.com', '$2y$10$sAkBLpDM2sR5wu30BrqBMuiJsD2K0ZoBcNbYQLpbb7OsPG7SeXMBm', NULL, NULL, '0877778819', NULL, NULL, NULL, 2, '2022-01-17 02:33:29', '2022-01-17 02:33:29'),
(24, 'Võ Nguyên', 'Voanhnguyenxd@gmail.com', '$2y$10$Zdh37wYRPthLSQ2BsCnbRO4yyhu/ljsnX5w/RwJK4ug2pQlGmdGzG', NULL, NULL, '0889196554', NULL, NULL, NULL, 2, '2022-01-17 03:16:18', '2022-01-17 03:16:18'),
(25, 'Trần Quang Phú', 'tranquangphu29@gmail.com', '$2y$10$Hes.tJRBtxiJYa.SRffrJ.GepPilsDBQ2iKX6/RL3jagZf16CU42G', '2022-01-01', 'Da Nang', '0839641618', 'Nam', 'Viet Nam', NULL, 2, '2022-01-17 03:34:48', '2022-01-19 19:38:54'),
(27, 'Quản lý', 'quanly@gmail.com', '$2y$10$GGo91UdV/tngKYm.VexUmuQknf7Z3//C.na6y2PSO/p3g6csX5U/i', NULL, NULL, '0877778819', NULL, NULL, NULL, 0, '2022-01-17 16:58:27', '2022-01-17 16:58:27'),
(28, 'Van Tu', 'tu@gmail.com', '$2y$10$93uwHJWUcRvnwAGGg2M72ecANLCr8hBOhwpCaq2t64VMpF2yewcSe', '2022-01-01', 'Quang Nam', '0877777777', 'Nam', 'Viet Nam', NULL, 2, '2022-01-18 01:39:26', '2022-01-19 19:38:40'),
(29, 'văn quý thọ', 'vanquytho12345@gmail.com', '$2y$10$mqKX7olIxKOPmItoeKiuw./.44IeVbv009ba12SizhoHKSPjhb08G', '2022-01-01', 'Da Nang', '0889198108', 'Nam', 'Viet Nam', NULL, 2, '2022-01-19 06:45:49', '2022-01-19 19:38:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `trang_thai_dat_san`
--

CREATE TABLE `trang_thai_dat_san` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ma_trang_thai` int(11) NOT NULL,
  `ten_trang_thai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Đang đổ dữ liệu cho bảng `trang_thai_dat_san`
--

INSERT INTO `trang_thai_dat_san` (`id`, `ma_trang_thai`, `ten_trang_thai`, `created_at`, `updated_at`) VALUES
(2, 2, 'Đã đặt', NULL, NULL),
(3, 3, 'Đã hủy', NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chi_tiet_dat_san`
--
ALTER TABLE `chi_tiet_dat_san`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_tk` (`ma_tk`) USING BTREE,
  ADD KEY `ma_san` (`ma_san`),
  ADD KEY `ma_loai_dv` (`ma_loai_dv`);

--
-- Chỉ mục cho bảng `chi_tiet_dich_vu`
--
ALTER TABLE `chi_tiet_dich_vu`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `dat_san`
--
ALTER TABLE `dat_san`
  ADD PRIMARY KEY (`id`,`ma_tk`) USING BTREE,
  ADD KEY `ma_tk` (`ma_tk`) USING BTREE,
  ADD KEY `ma_trang_thai` (`ma_trang_thai`) USING BTREE,
  ADD KEY `ma_tk_2` (`ma_tk`);

--
-- Chỉ mục cho bảng `dich_vu`
--
ALTER TABLE `dich_vu`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_loai_dv` (`ma_loai_dv`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `gia_theo_khung_gio`
--
ALTER TABLE `gia_theo_khung_gio`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_loai_san` (`ma_loai_san`);

--
-- Chỉ mục cho bảng `loai_dich_vu`
--
ALTER TABLE `loai_dich_vu`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_dv` (`ma_dv`) USING BTREE;

--
-- Chỉ mục cho bảng `loai_san`
--
ALTER TABLE `loai_san`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_san` (`ma_san`) USING BTREE;

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`) USING BTREE;

--
-- Chỉ mục cho bảng `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `qui_dinh`
--
ALTER TABLE `qui_dinh`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Chỉ mục cho bảng `quyen`
--
ALTER TABLE `quyen`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_quyen` (`ma_quyen`) USING BTREE;

--
-- Chỉ mục cho bảng `san`
--
ALTER TABLE `san`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_loai_san` (`ma_loai_san`) USING BTREE;

--
-- Chỉ mục cho bảng `tai_khoan`
--
ALTER TABLE `tai_khoan`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `tai_khoan_email_unique` (`email`) USING BTREE,
  ADD KEY `ma_quyen` (`ma_quyen`) USING BTREE;

--
-- Chỉ mục cho bảng `trang_thai_dat_san`
--
ALTER TABLE `trang_thai_dat_san`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `ma_trang_thai` (`ma_trang_thai`) USING BTREE;

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `users_email_unique` (`email`) USING BTREE;

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chi_tiet_dat_san`
--
ALTER TABLE `chi_tiet_dat_san`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `chi_tiet_dich_vu`
--
ALTER TABLE `chi_tiet_dich_vu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `dat_san`
--
ALTER TABLE `dat_san`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT cho bảng `dich_vu`
--
ALTER TABLE `dich_vu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `gia_theo_khung_gio`
--
ALTER TABLE `gia_theo_khung_gio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `loai_dich_vu`
--
ALTER TABLE `loai_dich_vu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `loai_san`
--
ALTER TABLE `loai_san`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `qui_dinh`
--
ALTER TABLE `qui_dinh`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `quyen`
--
ALTER TABLE `quyen`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `san`
--
ALTER TABLE `san`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `tai_khoan`
--
ALTER TABLE `tai_khoan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT cho bảng `trang_thai_dat_san`
--
ALTER TABLE `trang_thai_dat_san`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chi_tiet_dat_san`
--
ALTER TABLE `chi_tiet_dat_san`
  ADD CONSTRAINT `chi_tiet_dat_san_ibfk_1` FOREIGN KEY (`ma_san`) REFERENCES `san` (`id`),
  ADD CONSTRAINT `chi_tiet_dat_san_ibfk_2` FOREIGN KEY (`ma_loai_dv`) REFERENCES `dich_vu` (`ma_loai_dv`),
  ADD CONSTRAINT `ma_tk` FOREIGN KEY (`ma_tk`) REFERENCES `dat_san` (`ma_tk`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `dat_san`
--
ALTER TABLE `dat_san`
  ADD CONSTRAINT `dat_san_ibfk_1` FOREIGN KEY (`ma_tk`) REFERENCES `tai_khoan` (`id`),
  ADD CONSTRAINT `ma_trang_thai` FOREIGN KEY (`ma_trang_thai`) REFERENCES `trang_thai_dat_san` (`ma_trang_thai`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `dich_vu`
--
ALTER TABLE `dich_vu`
  ADD CONSTRAINT `ma_loai_dv` FOREIGN KEY (`ma_loai_dv`) REFERENCES `loai_dich_vu` (`ma_dv`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `gia_theo_khung_gio`
--
ALTER TABLE `gia_theo_khung_gio`
  ADD CONSTRAINT `gia_theo_khung_gio_ibfk_1` FOREIGN KEY (`ma_loai_san`) REFERENCES `loai_san` (`id`);

--
-- Các ràng buộc cho bảng `san`
--
ALTER TABLE `san`
  ADD CONSTRAINT `ma_loai_san` FOREIGN KEY (`ma_loai_san`) REFERENCES `loai_san` (`ma_san`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `tai_khoan`
--
ALTER TABLE `tai_khoan`
  ADD CONSTRAINT `ma_quyen` FOREIGN KEY (`ma_quyen`) REFERENCES `quyen` (`ma_quyen`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
